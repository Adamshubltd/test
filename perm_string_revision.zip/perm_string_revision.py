import random

ages = ['age', 'free', 'one', 'cone', 'tone', 'red', 'reap', 'flee', 'gone', 'near', 'done']
strings = 'abcdefghjiklmnopqrstuvwxyz'

new_arr = []
while True:
    
    t = random.sample(strings, k = 4)
    combine = ''.join(t).strip()
    if combine not in ages:
        continue
    else:
        new_arr.append(combine)
        if len(new_arr) == 2:
            break

print(new_arr)
print(list(set(new_arr)))




def permutation(n, r):
    x = 1
    y = 1
    p = n - r
    for t in range(1, n+1):
        x *= t
        
    for q in range (1, p+1):
        y *= q
    permu = int(x/y)
    print(f'Here is your answer {permu}')

permutation(7, 4)

